//+----------------------------------------------------------------------------
//|
//| FILENAME: ${filename}
//|
//| PROJECT: ${project}
//|
//| FILE DESCRIPTION:
//|    ${description}
//|
//+----------------------------------------------------------------------------
//|
//| Copyright 2010 by Exar. All text contained within remains property
//| of Exar corporation and may not be modified, distributed, or
//| reproduced without the express written permission of Exar.
//|
//+----------------------------------------------------------------------------

#define u64 unsigned long long
#define u32 unsigned int
#define u16 unsigned short
#define u8  unsigned char

#define lld_features_t int
#define lld_alarm_stats int
#define erom_info_t int

#define vBIT(val, loc, sz)  (((u64)(val)) << (64-(loc)-(sz)))
#define bVALn(bits, loc, n) ((((u64)bits) >> (64-(loc+n))) & ((0x1ULL << n) - 1))

${code}

