/** @file ${filename}
 ******************************************************************************
 *
 * @brief
 *    ${description}
 *
 ******************************************************************************
 *
 * @author
 * This file contains information proprietary to Cortina Systems, Inc.
 * (Cortina). Any use or disclosure, in whole or in part, of this
 * information to any unauthorized party, for any purposes other than that for
 * which it is provided is expressly prohibited except as authorized by
 * Cortina in writing. Cortina reserves its rights to pursue both civil and
 * criminal penalties for copying or disclosure of this material without
 * authorization. Cortina Systems (R), Cortina (TM) and the Cortina Systems
 * Earth Logo are the trademarks or registered trademarks of Cortina Systems,
 * Inc. and its subsidiaries in the U.S. and other countries. Any other
 * product and company names are the trademarks of their respective owners.
 * Copyright (C) 2006-2010 Cortina Systems, Inc. All rights reserved.
 *
 *****************************************************************************/

#include <stdio.h>
#pragma warning( disable : 4716 )

#include "leeds_hal.h"

${includes}

${code}

